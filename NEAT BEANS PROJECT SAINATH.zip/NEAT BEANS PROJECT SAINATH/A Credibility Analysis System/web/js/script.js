// <![CDATA[
$(function() {

  // Slider
  $('#coin-slider').coinslider({width:960,height:360,opacity:1});

  // Radius Box
  $('a.rm').css({"border-radius":"16px", "-moz-border-radius":"16px", "-webkit-border-radius":"16px"});
  $('img.fl').css({"border-radius":"10px", "-moz-border-radius":"10px", "-webkit-border-radius":"10px"});
  $('.menu_nav ul li a').css({"border-radius":"22px", "-moz-border-radius":"22px", "-webkit-border-radius":"22px"});
  //$('.header_resize').css({"border-top-left-radius":"16px", "border-top-right-radius":"16px", "-moz-border-radius-topleft":"16px", "-moz-border-radius-topright":"16px", "-webkit-border-top-left-radius":"16px", "-webkit-border-top-right-radius":"16px"});

});	

// Cufon
Cufon.replace('h1, h2, h3, h4, h5, h6, .menu_nav ul li a', { hover: true });

// ]]>